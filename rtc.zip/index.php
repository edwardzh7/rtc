<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Dashboard</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="dash-widget">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash1.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="307144.00">$307,144.00</span></h5>
                                <h6>Deposit Wallet</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>USDT Wallet</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->


                <div class="card mb-5">
                    <div class="card-body">
                        <h4 class="card-title">MT5 Account</h4>
                        <div class="table-responsive dataview">
                            <table class="table datatable ">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Project</th>
                                        <th>MT5 Account</th>
                                        <th>Password</th>
                                        <th>MT5 Balance</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td>25-11-2022</td>
                                        <td>A</td>
                                        <td>Stawberry</td>
                                        <td>N/D</td>
                                        <td>$ 1,000.00</td>
                                        <td><span class="badges bg-lightgreen">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <td>25-11-2022</td>
                                        <td>A</td>
                                        <td>Stawberry</td>
                                        <td>N/D</td>
                                        <td>$ 1,000.00</td>
                                        <td><span class="badges bg-lightred">Pending</span></td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card mb-0">
                    <div class="card-body">
                        <h4 class="card-title">Current Rank: USER</h4>
                        <div class="table-responsive dataview">
                            <table class="table datatable ">
                                <thead>
                                    <tr>
                                        <th>Next Rank</th>
                                        <th> Personal Funding</th>
                                        <th> Direct Sponsor / IB</th>
                                        <th>Direct Sales</th>
                                        <th> Team Performance</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td>Normal</td>
                                        <td> 0.00 / 1,000.00</td>
                                        <td>0 /</td>
                                        <td> 0.00 / 0.00</td>
                                        <td> 0.00 / 0.00</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Main Wrapper -->

    <?php include "js.php" ?>

</body>

</html>
