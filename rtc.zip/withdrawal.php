<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Withdrawal</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="dash-widget">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash1.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="307144.00">$307,144.00</span></h5>
                                <h6>Deposit Wallet</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>USDT Wallet</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->

                <!-- Default Browser Validation -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Withdrawal</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm">
                                <form>
                                    <div class="form-row row">
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefault01">Withdraw To</label>
                                            <input type="text" class="form-control" id="validationDefault01" placeholder="First name" value="123sdscoiosncdii423788429" readonly>
                                        </div>
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefault02">Withdrawal Amount </label>
                                            <input type="text" class="form-control" id="validationDefault02" placeholder="Please enter an amount greater than or equal to 1000, or a multiple of 1000." required>
                                        </div>
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefaultUsername">Security Password</label>
                                            <div class="input-group">
                                                <input type="password" class="form-control" id="validationDefaultUsername" placeholder="Please enter your security password to complete withdrawal" aria-describedby="inputGroupPrepend2" required>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-row row">
                                        <div class="col-md-8 mb-3" style="margin-left:10px;border:1px dash red;border-radius:5px;">
                                            <h5><b>Remark:</b></h5>
                                            <ul>
                                                <li>
                                                    <p>The minimum USDT(TRC20) withdrawal amount is 10 USD.</p>
                                                </li>
                                                <li>
                                                    <p>Please ensure that your withdrawal address USDT(TRC20) enter correctly, we will not be responsible for any loss or damage due to the wrong wallet address entered.</p>
                                                </li>
                                                <li>
                                                    <p>Please be noted that there's a 3 USD processing fee will be charged while making a withdrawal.</p>
                                                </li>
                                            </ul>


                                        </div>
                                    </div>
                                    <div class="mb-5 col-md-8" style="margin-left:20px;margin-right:20px;border-bottom:1px solid gray"></div>
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Default Browser Validation -->
                <div class="card mb-5">
                    <div class="card-body">
                        <h4 class="card-title">Withdrawal Statement</h4>
                        <div class="table-responsive dataview">
                            <table class="table datatable ">
                                <thead>
                                    <tr>
                                        <th>Transaction ID</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td>25-11-2022</td>
                                        <td>A</td>
                                        <td>$ 1,000.00</td>
                                        <td><span class="badges bg-lightgreen">Completed</span></td>
                                        <td>-</td>
                                    </tr>
                                    <tr>
                                        <td>25-11-2022</td>
                                        <td>A</td>
                                        <td>$ 1,000.00</td>
                                        <td><span class="badges bg-lightred">Pending</span></td>
                                        <td>-</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Main Wrapper -->

    <<?php include "js.php" ?> </body>

</html>
