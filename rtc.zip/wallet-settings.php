<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Wallet Settings</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->

                <!-- Default Browser Validation -->
                <div class="row">
                    <div class="col-sm-12 col-md-8 col-lg-8 mb-3">

                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Change Wallet Address</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm">
                                        <form>
                                            <div class="form-row row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefault01">Current Wallet Address</label>
                                                    <input type="text" class="form-control" id="validationDefault01" placeholder="Current Wallet Address" required>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefaultUsername">OTP</label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="Enter OTP to confirm authority" aria-describedby="inputGroupPrepend2" required>
                                                        <button class="btn btn-primary" type="submit">Request OTP</button>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="mb-5 col-md-9" style="margin-left:20px;margin-right:20px;border-bottom:1px solid gray"></div>
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Main Wrapper -->

    <<?php include "js.php" ?> </body>

</html>
