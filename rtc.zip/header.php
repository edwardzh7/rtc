<!-- Header -->
<div class="header" style="background:#F1E5AC">

    <!-- Logo -->
    <div class="header-left active">
        <a href="index.php" class="logo logo-normal">
            <img src="assets/img/logo.png" alt="">
        </a>
        <a href="index.php" class="logo logo-white">
            <img src="assets/img/logo-white.png" alt="">
        </a>
        <a href="index.php" class="logo-small">
            <img src="assets/img/logo-small.png" alt="">
        </a>
    </div>
    <!-- /Logo -->

    <a id="mobile_btn" class="mobile_btn" href="#sidebar">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>

    <!-- Header Menu -->
    <ul class="nav user-menu">



        <!-- Flag -->
        <li class="nav-item dropdown has-arrow flag-nav">
            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="javascript:void(0);" role="button">
                <img src="assets/img/flags/us1.png" alt="" height="20">
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="javascript:void(0);" class="dropdown-item">
                    <img src="assets/img/flags/us.png" alt="" height="16"> English
                </a>
                <a href="javascript:void(0);" class="dropdown-item">
                    <img src="assets/img/flags/fr.png" alt="" height="16"> French
                </a>
                <a href="javascript:void(0);" class="dropdown-item">
                    <img src="assets/img/flags/es.png" alt="" height="16"> Spanish
                </a>
                <a href="javascript:void(0);" class="dropdown-item">
                    <img src="assets/img/flags/de.png" alt="" height="16"> German
                </a>
            </div>
        </li>
        <!-- /Flag -->


        <li class="nav-item dropdown has-arrow main-drop">
            <a href="javascript:void(0);" class="dropdown-toggle nav-link userset" data-bs-toggle="dropdown">
                <span class="user-img"><img src="assets/img/profiles/avator1.jpg" alt="">
                    <span class="status online"></span></span>
            </a>
            <div class="dropdown-menu menu-drop-user">
                <div class="profilename">
                    <div class="profileset">
                        <span class="user-img"><img src="assets/img/profiles/avator1.jpg" alt="">
                            <span class="status online"></span></span>
                        <div class="profilesets">
                            <h6>John Doe</h6>
                            <h5>Admin</h5>
                        </div>
                    </div>
                    <hr class="m-0">
                    <a class="dropdown-item" href="profile.php"> <i class="me-2" data-feather="user"></i> My Profile</a>
                    <a class="dropdown-item" href="security.php"><i class="me-2" data-feather="settings"></i>Account Settings</a>
                    <a class="dropdown-item" href="wallet-settings.php"><i class="me-2" data-feather="settings"></i>Wallet Settings</a>
                    <hr class="m-0">
                    <a class="dropdown-item logout pb-0" href="signin.php"><img src="assets/img/icons/log-out.svg" class="me-2" alt="img">Logout</a>
                </div>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->

    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="profile.php">My Profile</a>
            <a class="dropdown-item" href="security.php">Account Settings</a>
            <a class="dropdown-item" href="wallet-settings.php">Settings</a>
            <a class="dropdown-item" href="signin.php">Logout</a>
        </div>
    </div>
    <!-- /Mobile Menu -->
</div>
<!-- Header -->

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll" style="background:#F1E5AC">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="active">
                    <a href="index.php"><img src="assets/img/icons/dashboard.svg" alt="img"><span> Dashboard</span> </a>
                </li>

                <li>
                    <a href="deposit.php"><img src="assets/img/icons/expense1.svg" alt="img"><span> Deposit</span> </a>
                </li>
                <li>
                    <a href="withdrawal.php"><img src="assets/img/icons/transfer1.svg" alt="img"><span> Withdrawal</span> </a>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><img src="assets/img/icons/purchase1.svg" alt="img"><span> Statement</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a href="statement.php">Wallet Statement</a></li>
                        <li><a href="profit-statement.php">Profit Statement</a></li>
                    </ul>
                </li>
                <li>
                    <a href="team.php"><img src="assets/img/icons/users1.svg" alt="img"><span> Team</span> </a>
                </li>
                <li>
                    <a href="components.php"><i data-feather="layers"></i><span> Download</span> </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
