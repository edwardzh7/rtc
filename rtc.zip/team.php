	<!DOCTYPE html>
	<html lang="en">

	<?php include "head.php" ?>

	<body>
	    <div id="global-loader">
	        <div class="whirly-loader"> </div>
	    </div>
	    <!-- Main Wrapper -->
	    <div class="main-wrapper">

	        <!-- Header -->
	        <?php include "header.php" ?>
	        <!-- /Sidebar -->

	        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
	            <div class="content">
	                <div class="comp-sec-wrapper">

	                    <!-- Cards -->
	                    <section class="comp-section comp-cards">
	                        <div class="section-header">
	                            <h3 class="section-title">Team</h3>
	                            <div class="line"></div>
	                        </div>

	                        <div class="row">

	                            <div class="col-12 col-md-6 col-lg-4 d-flex">
	                                <div class="card flex-fill bg-white">
	                                    <img alt="Card Image" src="assets/img/img-01.jpg" class="card-img-top">
	                                    <div class="card-header">
	                                        <h5 class="card-title mb-0">Invitation Link</h5>
	                                    </div>
	                                    <div class="card-body">
	                                        <p class="card-text">Share this invitation link or membership QR code with your friends to get them to register under your account to receive rewards.</p>
	                                        <a class="btn btn-primary" href="javascript:void(0);"><i class="far fa-copy"></i> Copy</a>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                    </section>
	                    <!-- /Cards -->
	                </div>
	            </div>
	        </div>

	    </div>
	    <!-- /Main Wrapper -->

	    <?php include "js.php" ?>

	</body>

	</html>
