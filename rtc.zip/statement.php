<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Wallet Statement</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card bg-white">
                            <div class="card-header">
                                <h5 class="card-title">Activity Summary</h5>
                            </div>
                            <div class="card-body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link active" href="#basictab1" data-bs-toggle="tab">Deposit Wallet</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#basictab2" data-bs-toggle="tab">USDT Wallet</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#basictab3" data-bs-toggle="tab">SAFU</a></li>
                                </ul>
                                <div class="tab-content mt-5">
                                    <div class="tab-pane show active" id="basictab1">
                                        <div class="table-responsive dataview">
                                            <table class="table datatable ">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Details</th>
                                                        <th>Balance (Initial)</th>
                                                        <th>Amount</th>
                                                        <th>Wallet Balance</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>25-11-2022</td>
                                                        <td>A</td>
                                                        <td>$ 1,000.00</td>
                                                        <td><span class="badges bg-lightgreen">Completed</span></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td>25-11-2022</td>
                                                        <td>A</td>
                                                        <td>$ 1,000.00</td>
                                                        <td><span class="badges bg-lightred">Pending</span></td>
                                                        <td>-</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="basictab2">
                                        <div class="table-responsive dataview">
                                            <table class="table datatable ">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Details</th>
                                                        <th>Balance (Initial)</th>
                                                        <th>Amount</th>
                                                        <th>Wallet Balance</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>25-11-2023</td>
                                                        <td>A</td>
                                                        <td>$ 1,000.00</td>
                                                        <td><span class="badges bg-lightgreen">Completed</span></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td>25-11-2023</td>
                                                        <td>A</td>
                                                        <td>$ 1,000.00</td>
                                                        <td><span class="badges bg-lightred">Pending</span></td>
                                                        <td>-</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="basictab3">
                                        <div class="table-responsive dataview">
                                            <table class="table datatable ">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Details</th>
                                                        <th>Balance (Initial)</th>
                                                        <th>Amount</th>
                                                        <th>Wallet Balance</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>26-11-2022</td>
                                                        <td>A</td>
                                                        <td>$ 1,000.00</td>
                                                        <td><span class="badges bg-lightgreen">Completed</span></td>
                                                        <td>-</td>
                                                    </tr>
                                                    <tr>
                                                        <td>26-11-2022</td>
                                                        <td>A</td>
                                                        <td>$ 1,000.00</td>
                                                        <td><span class="badges bg-lightred">Pending</span></td>
                                                        <td>-</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->
            </div>
        </div>

    </div>
    <!-- /Main Wrapper -->

    <<?php include "js.php" ?> </body>

</html>
