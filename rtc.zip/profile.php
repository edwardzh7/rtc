<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Profile Management</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->

                <!-- Default Browser Validation -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Account Verification Status</h5>
                        <p class="card-text">Your account is not verified. Please verify KYC now to activate your account.</p>
                        <a href="kyc.php" class="btn btn-primary">Verify KYC</a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm">
                                <form>
                                    <div class="form-row row">
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefault01">Username</label>
                                            <input type="text" class="form-control" id="validationDefault01" placeholder="First name" value="tech001" readonly>
                                        </div>
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefault02">Full Name</label>
                                            <input type="text" class="form-control" id="validationDefault02" placeholder="Tech Account" required>
                                        </div>
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefaultUsername">Identity Card No./ Passport No.</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="validationDefaultUsername" placeholder="Identity Card No./ Passport No" aria-describedby="inputGroupPrepend2" required>
                                            </div>
                                        </div>
                                        <div class="col-md-8 mb-3">
                                            <label for="validationDefaultUsername">Email</label>
                                            <div class="input-group">
                                                <input type="email" class="form-control" id="validationDefaultUsername" placeholder="Email" aria-describedby="inputGroupPrepend2" required>
                                                <button class="btn btn-primary" type="submit">Change Email</button>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="mb-5 col-md-8" style="margin-left:20px;margin-right:20px;border-bottom:1px solid gray"></div>
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Main Wrapper -->

    <<?php include "js.php" ?> </body>

</html>
