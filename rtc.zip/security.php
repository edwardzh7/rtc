<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Account Settings</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->

                <!-- Default Browser Validation -->
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-6 mb-3">

                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Change Security Password</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm">
                                        <form>
                                            <div class="form-row row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefault01">Current Security Password</label>
                                                    <input type="password" class="form-control" id="validationDefault01" placeholder="Current Security Password" required>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefault02">New Security Password</label>
                                                    <input type="password" class="form-control" id="validationDefault02" placeholder="New Security Password" required>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefaultUsername">Retype New Security Password</label>
                                                    <div class="input-group">
                                                        <input type="password" class="form-control" id="validationDefaultUsername" placeholder="Retype New Security Password" aria-describedby="inputGroupPrepend2" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefaultUsername">OTP</label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="Enter OTP to confirm authority" aria-describedby="inputGroupPrepend2" required>
                                                        <button class="btn btn-primary" type="submit">Request OTP</button>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="mb-5 col-md-12" style="margin-left:20px;margin-right:20px;border-bottom:1px solid gray"></div>
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 mb-3">

                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Change Login Password</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm">
                                        <form>
                                            <div class="form-row row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefault01">Current Login Password</label>
                                                    <input type="password" class="form-control" id="validationDefault01" placeholder="Current Login Password" required>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefault02">New Login Password</label>
                                                    <input type="password" class="form-control" id="validationDefault02" placeholder="New Login Password" required>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefaultUsername">Retype New Login Password</label>
                                                    <div class="input-group">
                                                        <input type="password" class="form-control" id="validationDefaultUsername" placeholder="Retype New Login Password" aria-describedby="inputGroupPrepend2" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="validationDefaultUsername">OTP</label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="Enter OTP to confirm authority" aria-describedby="inputGroupPrepend2" required>
                                                        <button class="btn btn-primary" type="submit">Request OTP</button>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="mb-5 col-md-12" style="margin-left:20px;margin-right:20px;border-bottom:1px solid gray"></div>
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Main Wrapper -->

    <<?php include "js.php" ?> </body>

</html>
