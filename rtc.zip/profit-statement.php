<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>

<body>
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>
        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="section-header">
                            <h3 class="section-title">Profit Statement</h3>
                            <div class="line"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>Profit Sharing</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>Team Bonus</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>Leadership Bonus</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>Trading IB</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="dash-widget dash1">
                            <div class="dash-widgetimg">
                                <span><img src="assets/img/icons/dash2.svg" alt="img"></span>
                            </div>
                            <div class="dash-widgetcontent">
                                <h5>$<span class="counters" data-count="4385.00">$4,385.00</span></h5>
                                <h6>Core IB</h6>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card bg-white">
                        <div class="card-header">
                            <h5 class="card-title">Activity Summary</h5>
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-tabs">
                                <li class="nav-item"><a class="nav-link active" href="#profitsharing" data-bs-toggle="tab">Profit Sharing Bonus</a></li>
                                <li class="nav-item"><a class="nav-link" href="#teambonus" data-bs-toggle="tab">Team Bonus</a></li>
                                <li class="nav-item"><a class="nav-link" href="#leadership" data-bs-toggle="tab">Leadership Bonus</a></li>
                                <li class="nav-item"><a class="nav-link" href="#tradingib" data-bs-toggle="tab">Trading IB Rebate</a></li>
                                <li class="nav-item"><a class="nav-link" href="#coreib" data-bs-toggle="tab">Core IB Rebate</a></li>
                            </ul>
                            <div class="tab-content mt-5">
                                <div class="tab-pane show active" id="profitsharing">
                                    <div class="table-responsive dataview">
                                        <table class="table datatable ">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Profit Sharing</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>
                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Profit Sharing</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane" id="teambonus">
                                    <div class="table-responsive dataview">
                                        <table class="table datatable ">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Team Bonus</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>
                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Team Bonus</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane" id="leadership">
                                    <div class="table-responsive dataview">
                                        <table class="table datatable ">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Leadership Bonus</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>
                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>A\Leadership Bonus</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tradingib">
                                    <div class="table-responsive dataview">
                                        <table class="table datatable ">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Trading IB</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>
                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Trading IB</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane" id="coreib">
                                    <div class="table-responsive dataview">
                                        <table class="table datatable ">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Core IB</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>
                                                <tr>
                                                    <td>25-11-2022</td>
                                                    <td>Core IB</td>
                                                    <td>$ 1,000.00</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Button trigger modal -->
        </div>
    </div>

    </div>
    <!-- /Main Wrapper -->

    <<?php include "js.php" ?> </body>

</html>
