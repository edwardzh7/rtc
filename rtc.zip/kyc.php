<!DOCTYPE html>
<html lang="en">
<?php include "head.php" ?>


<body>

    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>


    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php include "header.php" ?>

        <!-- /Sidebar -->

        <div class="page-wrapper" style="background:rgb(253 240 180 / 85%)">
            <div class="content">
                <div class="page-header">
                    <div class="page-title">
                        <h4>KYC Verification</h4>
                    </div>
                </div>
                <!-- /add -->
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="form-group">
                                    <label>IC Front</label>
                                    <div class="image-upload">
                                        <input type="file">
                                        <div class="image-uploads">
                                            <img src="assets/img/icons/upload.svg" alt="img">
                                            <h4>Select file to upload</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="form-group">
                                    <label>IC Back</label>
                                    <div class="image-upload">
                                        <input type="file">
                                        <div class="image-uploads">
                                            <img src="assets/img/icons/upload.svg" alt="img">
                                            <h4>Select file to upload</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row row">
                                <div class="col-md-8 mb-3" style="margin-left:10px;border:1px dash red;border-radius:5px;">
                                    <h5><b>Remark:</b></h5>
                                    <ul>
                                        <li>
                                            <p>- To ensure a smooth identity verification, it is advisable to make sure all info is clear and readable.</p>
                                        </li>
                                        <li>
                                            <p>- Select only .jpg, .png file.</p>
                                        </li>
                                    </ul>


                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="javascript:void(0);" class="btn btn-submit me-2">Submit</a>
                                    <a href="javascript:void(0);" class="btn btn-cancel">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /add -->
            </div>
        </div>
    </div>
    <!-- /Main Wrapper -->

    <?php include "js.php" ?>


</body>

</html>
